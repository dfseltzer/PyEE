"""
Core math function and class definitions
"""