"""
Core unit functions and definitions
"""